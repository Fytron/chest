"""
refactor_langchain_v1.py
Refactored to LangChain v1 idioms:
 - v1 imports and patterns
 - Document loaders -> directory walk, support pdf/txt/docx
 - RecursiveCharacterTextSplitter for parent/child splitting
 - FAISS vectorstore built from documents (fallback to manual index)
 - ParentDocumentRetriever using InMemoryStore
 - Tool defined with @tool decorator
 - create_agent / agent.invoke usage
 - RunnableWithMessageHistory wrapper for conversational history
"""

import os
import uuid
import yaml
import faiss
from typing import List, Optional

# === LangChain v1 imports (idiomatic) ===
from langchain_community.document_loaders import DirectoryLoader, PyPDFLoader, TextLoader, UnstructuredFileLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_classic.retrievers import ParentDocumentRetriever
from langchain_classic.storage import InMemoryStore
from langchain_community.docstore.in_memory import InMemoryDocstore
from langchain_classic.schema import Document

from langchain.chat_models import init_chat_model  # v1 chat model initializer
from langchain_ollama import ChatOllama
from langchain.tools import tool
from langchain.agents import create_agent
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage, ToolMessage

# === local config / constants ===
cwd = os.getcwd()
CONFIG_PATH = os.path.join(cwd, "config.yml")
DOCUMENTS_FOLDER = os.path.join(cwd, "documents")
SESSION_STORE = {}  # for RunnableWithMessageHistory

# === Load config (API keys etc.) ===
with open(CONFIG_PATH, "r") as f:
    config = yaml.safe_load(f)

# Example: set OPENAI_API_KEY if using OpenAIEmbeddings
if "api_key" in config and config["api_key"]:
    os.environ["OPENAI_API_KEY"] = config["api_key"]

# === 1) Document loading utilities ===
def load_documents_from_folder(folder_path: str) -> List[Document]:
    """
    Walk folder_path and load supported files into a list of langchain.schema.Document
    Supported: .pdf, .txt, .docx
    """
    supported_extensions = {".pdf", ".txt", ".docx"}
    docs: List[Document] = []

    for root, _, files in os.walk(folder_path):
        for filename in files:
            path = os.path.join(root, filename)
            _, ext = os.path.splitext(path)
            ext = ext.lower()

            try:
                if ext == ".pdf":
                    loader = PyPDFLoader(path)
                    loaded = loader.load()
                elif ext == ".txt":
                    loader = TextLoader(path, encoding="utf-8")
                    loaded = loader.load()
                elif ext == ".docx":
                    # UnstructuredFileLoader works for many office formats
                    loader = UnstructuredFileLoader(path)
                    loaded = loader.load()
                else:
                    print(f"Skipping unsupported file: {path}")
                    continue

                # Ensure loaded elements are Document instances
                for d in loaded:
                    if isinstance(d, Document):
                        # add unique id to metadata if not present
                        if "doc_id" not in d.metadata:
                            d.metadata = dict(d.metadata) if d.metadata else {}
                            d.metadata["doc_id"] = str(uuid.uuid4())
                        if d.page_content and d.page_content.strip():
                            docs.append(d)
                    else:
                        # If loader returned tuples or raw dicts, try to convert
                        try:
                            page_content = getattr(d, "page_content", None) or (d[0] if isinstance(d, (list, tuple)) and len(d) > 0 else None)
                            metadata = getattr(d, "metadata", None) or (d[1] if isinstance(d, (list, tuple)) and len(d) > 1 else {})
                            if page_content:
                                docs.append(Document(page_content=page_content, metadata={**(metadata or {}), "doc_id": str(uuid.uuid4())}))
                        except Exception:
                            print(f"Skipping invalid loaded item from {path}: {type(d)}")
            except Exception as e:
                print(f"Error loading {path}: {e}")

    return docs

# === 2) Text splitters ===
parent_splitter = RecursiveCharacterTextSplitter(chunk_size=5000, chunk_overlap=200)
child_splitter = RecursiveCharacterTextSplitter(chunk_size=2000, chunk_overlap=50)

# === 3) Embeddings and FAISS setup ===
embeddings = OpenAIEmbeddings()  # or replace with another embedding provider

# Build FAISS vectorstore the simple way: FAISS.from_documents
def build_vectorstore(docs: List[Document], embeddings) -> FAISS:
    """
    Create a FAISS vectorstore from a list of Documents using provided embeddings.
    This uses FAISS.from_documents under-the-hood (preferred for simplicity).
    """
    # If the vectorstore helper supports from_documents, use it.
    try:
        vectorstore = FAISS.from_documents(docs, embeddings)
        return vectorstore
    except Exception:
        # Fallback: manual index creation (preserve original pattern)
        sample_embedding = embeddings.embed_query("Hello world")
        emb_dim = len(sample_embedding)
        index = faiss.IndexFlatL2(emb_dim)
        docstore = InMemoryDocstore()
        vectorstore = FAISS(
            index=index,
            embedding_function=embeddings,
            docstore=docstore,
            index_to_docstore_id={}
        )
        # Add embeddings manually
        for doc in docs:
            vectorstore.add_documents([doc])
        return vectorstore

# === 4) Load docs, build vectorstore & retriever ===
raw_docs = load_documents_from_folder(DOCUMENTS_FOLDER)
print(f"Loaded {len(raw_docs)} documents from {DOCUMENTS_FOLDER}.")

# Build vectorstore
vectorstore = build_vectorstore(raw_docs, embeddings)

# Memory store for ParentDocumentRetriever
memstore = InMemoryStore()

# Initialize ParentDocumentRetriever
retriever = ParentDocumentRetriever(
    vectorstore=vectorstore,
    docstore=memstore,
    child_splitter=child_splitter,
    parent_splitter=parent_splitter,
    id_key="doc_id",  # keep explicit id_key for clarity
)

# Add parent documents to the retriever (safe add)
try:
    retriever.add_documents(raw_docs)
    print(f"Added {len(raw_docs)} documents into ParentDocumentRetriever.")
except Exception as e:
    print(f"Error adding documents to retriever: {e}")

# === 5) Define tools ===
@tool
def scan_document(query: str) -> str:
    """
    Tool to retrieve relevant parent documents for a query and return their content.
    The LangChain agent will call this tool when asked to 'scan' or 'summarize' documents.
    """
    # ParentDocumentRetriever.invoke/query usage returns parent docs
    try:
        # The retriever's interface sometimes exposes .get_relevant_documents(query)
        # Use .get_relevant_documents if available; else fallback to .invoke
        if hasattr(retriever, "get_relevant_documents"):
            parent_docs = retriever.get_relevant_documents(query)
        else:
            parent_docs = retriever.invoke(query)  # v1 compatible invoke if implemented
    except Exception:
        # Last fallback: run vectorstore.search
        parent_docs = vectorstore.similarity_search(query, k=5)

    if not parent_docs:
        return "No relevant documents found."

    # Concatenate contents but cap size to prevent extremely long tool outputs
    MAX_CHARS = 20000
    concatenated = []
    chars = 0
    for d in parent_docs:
        text = d.page_content if hasattr(d, "page_content") else str(d)
        if not text:
            continue
        if chars + len(text) > MAX_CHARS:
            # truncate gracefully
            remaining = MAX_CHARS - chars
            concatenated.append(text[:remaining] + "\n\n[TRUNCATED]")
            break
        concatenated.append(text)
        chars += len(text)

    return "\n\n".join(concatenated)

@tool
def summarize_document(query: str, max_chunks: Optional[int] = 10):
    """
    Summarizes long documents in chunks.
    """
    try:
        docs = retriever.get_relevant_documents(query)
    except Exception:
        docs = retriever.invoke(query)

    if not docs:
        return "No relevant documents found."

    summaries = []
    for doc in docs:
        chunks = child_splitter.split_text(doc.page_content)
        chunk_summaries = []
        for chunk in chunks[:max_chunks]:
            response = chat_model.invoke([HumanMessage(content=f"Summarize this text concisely:\n{chunk}")])
            chunk_summaries.append(response.content)
        combined = "\n".join(chunk_summaries)
        final_summary = chat_model.invoke([HumanMessage(content=f"Summarize this combined summary briefly:\n{combined}")])
        summaries.append(final_summary.content)

    return "\n\n---\n\n".join(summaries)

from langchain.agents.middleware import ToolCallLimitMiddleware, SummarizationMiddleware, wrap_tool_call, AgentMiddleware

# @wrap_tool_call
# def logging_middleware(request, handler):
#     tool_name = getattr(request.tool, "name", "unknown")
#     inputs = getattr(request, "inputs", {})
#     print(f"[Middleware] Calling tool {tool_name} with inputs: {inputs}")

#     try:
#         result = handler(request)
#     except Exception as e:
#         print(f"[Middleware] Error during tool {tool_name}: {e}")
#         return ToolMessage(
#             content=f"Error in tool {tool_name}: {e}",
#             tool_call_id=getattr(request, "tool_call_id", None)
#         )

#     print(f"[Middleware] Tool {tool_name} returned: {result}")
#     return ToolMessage(
#         content=str(result),
#         tool_call_id=getattr(request, "tool_call_id", None)
#     )

# @wrap_tool_call
# def logging_middleware(request, handler):
#     print(request)
#     tool_name = getattr(request.tool, "name", "unknown")
#     inputs = getattr(request, "args", {})
#     print(f"[Middleware] Calling tool {tool_name} with inputs: {inputs}")

#     try:
#         result = handler(request)
#     except Exception as e:
#         print(f"[Middleware] Error during tool {tool_name}: {e}")
#         return ToolMessage(
#             content=f"Error in tool {tool_name}: {e}",
#             tool_call_id=request.tool_call_id,  # <-- Use this
#             name=tool_name
#         )

#     print(f"[Middleware] Tool {tool_name} returned: {result}")
#     return ToolMessage(
#         content=str(result),
#         tool_call_id=request.tool_call_id,  # <-- Use this
#         name=tool_name
#     )

@wrap_tool_call
def logging_middleware(request, handler):
    tool_name = getattr(request.tool, "name", "unknown")
    inputs = getattr(request, "args", {})
    tool_call_id = getattr(request, "tool_call_id", None)  # Safe way to access it

    print(f"[Middleware] Calling tool {tool_name} with inputs: {inputs}")

    try:
        result = handler(request)
        print(f"[Middleware] Tool {tool_name} returned: {result}")
        return result  # DO NOT wrap here — let framework handle it
    except Exception as e:
        print(f"[Middleware] Error during tool {tool_name}: {e}")
        raise  # Better to propagate error than wrap it here

# List of tools for agent creation
tools = [scan_document, summarize_document]

# === 6) Initialize the chat model (Ollama or other) and create an agent ===
# If you want to use Ollama, swap the model initializer or pass model="ollama:your-model"
# Here we'll use init_chat_model to stay compatible with v1 patterns.
# Replace "your-model-name" with an actual model id (e.g., "llama3.2:latest" for Ollama if configured)
# MODEL_NAME = config.get("ollama_model", "llama3.2:latest")  # override in config if you want
# chat_model = init_chat_model(MODEL_NAME, temperature=0.0, timeout=30)
MODEL_NAME = config.get("ollama_model", "llama3.2:latest")
chat_model = ChatOllama(
    model=MODEL_NAME,
    temperature=0,  # deterministic (optional)
)

# Example: limit tool usage
tool_limiter = ToolCallLimitMiddleware(thread_limit=20, run_limit=5)

# Example: summarize history to control context size
summarizer = SummarizationMiddleware(
    model=chat_model, 
    max_tokens_before_summary=2000  # tune based on your token limits
)

SYSTEM_PROMPT = """You are a helpful assistant with access to tools:
- scan_document: retrieve full document content
- summarize_document: summarize long documents chunk-wise
Keep answers concise and cite when appropriate.
Use tools when user requests summaries or scans."""

# create_agent accepts a model, system_prompt and tools in v1
agent = create_agent(
    model=chat_model,
    system_prompt=SYSTEM_PROMPT,
    tools=tools,
    middleware=[tool_limiter, summarizer, logging_middleware]
)

# === 7) Wrap agent with RunnableWithMessageHistory for conversations ===
def get_session_history(session_id: str):
    if session_id not in SESSION_STORE:
        SESSION_STORE[session_id] = InMemoryChatMessageHistory()
    return SESSION_STORE[session_id]

conversational_agent = RunnableWithMessageHistory(
    runnable=agent,
    get_session_history=get_session_history,
    input_messages_key="messages",       # v1 uses 'messages' lists
    history_messages_key="chat_history", # internal placeholder name
)

# === 8) Updated REPL with tool output + token usage ===
def extract_last_ai_message_with_tools(messages):
    """
    Extract the last AIMessage content and append any ToolMessage outputs
    that occurred after it. Returns (text, usage_metadata).
    """
    last_ai_index = None
    tool_texts = []

    # messages can be AIMessage, ToolMessage, HumanMessage, or dict
    for i, msg in enumerate(messages):
        # Normalize dict-like messages
        if isinstance(msg, dict):
            msg_type = msg.get("_type") or msg.get("type") or "unknown"
            content = msg.get("content", "")
        else:
            msg_type = type(msg).__name__
            content = getattr(msg, "content", "")

        if msg_type == "AIMessage":
            last_ai_index = i
        elif msg_type == "ToolMessage":
            if content:
                tool_texts.append(content)

    # Extract AI content
    if last_ai_index is not None:
        ai_msg = messages[last_ai_index]
        if isinstance(ai_msg, dict):
            ai_content = ai_msg.get("content", "")
            usage = ai_msg.get("usage_metadata", {})
        else:
            ai_content = getattr(ai_msg, "content", "")
            usage = getattr(ai_msg, "usage_metadata", {})
    else:
        ai_content = "(No assistant output)"
        usage = {}

    # Append tool output
    if tool_texts:
        ai_content += "\n\n--- Tool Output ---\n" + "\n\n".join(tool_texts)

    return ai_content, usage


SHOW_TOOL_OUTPUT = True  # Set True for debugging

# def run_repl():
#     print("Conversational agent started. Type 'exit' to quit.")
#     session_id = str(uuid.uuid4())
#     max_tokens = 4096  # adjust based on model context size

#     while True:
#         user_input = input("You: ").strip()
#         if user_input.lower() == "exit":
#             break

#         payload = {"messages": [{"role": "user", "content": user_input}]}
#         config = {
#             "configurable": {"thread_id": session_id},
#             "session_id": session_id
#         }

#         try:
#             result = conversational_agent.invoke(payload, config=config)

#             # The messages from the agent
#             messages = result.messages if hasattr(result, "messages") else []

#             # Extract last meaningful AI message
#             ai_content, usage = extract_last_ai_message_with_tools(messages) or "(No assistant output)"

#             # Optionally append tool output for debugging
#             if SHOW_TOOL_OUTPUT:
#                 tool_texts = [
#                     m.content for m in messages if m.type == "tool"
#                 ]
#                 if tool_texts:
#                     MAX_TOOL_OUTPUT_CHARS = 1500
#                     combined_tool_text = "\n\n".join(tool_texts)
#                     if len(combined_tool_text) > MAX_TOOL_OUTPUT_CHARS:
#                         combined_tool_text = combined_tool_text[:MAX_TOOL_OUTPUT_CHARS] + "\n... [truncated]"
#                     ai_content += "\n\n--- Tool Output ---\n" + combined_tool_text

#             # Token usage feedback
#             # usage = getattr(messages[-1], "usage_metadata", {}) if messages else {}
#             if usage:
#                 total = usage.get("total_tokens", 0)
#                 remaining_pct = (max_tokens - total) / max_tokens * 100
#                 suffix = f" ({remaining_pct:.1f}% context remaining)"
#             else:
#                 suffix = ""

#             print("Bot:", ai_content + suffix)

#         except Exception as e:
#             print("Agent error:", e)


def run_repl():
    print("Conversational agent started. Type 'exit' to quit.")
    session_id = str(uuid.uuid4())
    max_tokens = 4096  # adjust based on model context size

    history = get_session_history(session_id)

    # Add SYSTEM_PROMPT to new session if empty
    if len(history.messages) == 0:
        history.add_message(SystemMessage(content=SYSTEM_PROMPT))

    while True:
        user_input = input("You: ").strip()
        if user_input.lower() == "exit":
            break

        # Wrap input in HumanMessage
        user_msg = HumanMessage(content=user_input)
        payload = {"messages": [user_msg]}

        # Config for RunnableWithMessageHistory
        config = {
            "configurable": {"thread_id": session_id},
            "session_id": session_id
        }

        try:
            result = conversational_agent.invoke(payload, config=config)

            # Messages returned from agent
            messages = getattr(result, "messages", [])

            # Extract last AIMessage + tool outputs
            last_ai_content = "(No assistant output)"
            if messages:
                ai_msgs = [m for m in messages if isinstance(m, AIMessage)]
                if ai_msgs:
                    last_ai = ai_msgs[-1]
                    last_ai_content = last_ai.content

                if SHOW_TOOL_OUTPUT:
                    tool_outputs = [
                        getattr(m, "content", "") for m in messages
                        if type(m).__name__ == "ToolMessage" and getattr(m, "content", "")
                    ]
                    if tool_outputs:
                        MAX_TOOL_OUTPUT_CHARS = 1500
                        combined_tool_text = "\n\n".join(tool_outputs)
                        if len(combined_tool_text) > MAX_TOOL_OUTPUT_CHARS:
                            combined_tool_text = combined_tool_text[:MAX_TOOL_OUTPUT_CHARS] + "\n... [truncated]"
                        last_ai_content += "\n\n--- Tool Output ---\n" + combined_tool_text

            # Optionally display token usage
            usage = getattr(messages[-1], "usage_metadata", {}) if messages else {}
            suffix = ""
            if usage:
                total = usage.get("total_tokens", 0)
                remaining_pct = (max_tokens - total) / max_tokens * 100
                suffix = f" ({remaining_pct:.1f}% context remaining)"

            print("Bot:", last_ai_content + suffix)

        except Exception as e:
            print("Agent error:", e)

if __name__ == "__main__":
    run_repl()
